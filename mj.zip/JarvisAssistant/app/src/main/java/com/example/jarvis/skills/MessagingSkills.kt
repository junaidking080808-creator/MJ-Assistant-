package com.example.jarvis.skills

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat

private fun Context.launch(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

private fun lookup(ctx: Context, name: String): Pair<String, String>? =
    ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
        "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)
        ?.use { if (it.moveToFirst()) it.getString(0) to it.getString(1) else null }

/** Resolves a spoken target (digits or contact name) to (label, number), or returns an explanatory Plan. */
private fun withTarget(ctx: Context, target: String, build: (String, String) -> Plan): Plan {
    val t = target.trim().removePrefix("my ")
    if (t.length >= 4 && t.all { it.isDigit() || it in "+ -" }) return build(t, t.filter { it.isDigit() || it == '+' })
    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
        return Plan("", false) { "I need contacts permission. Enable it in the app's system settings." }
    val hit = lookup(ctx, t) ?: return Plan("", false) { "I couldn't find $t in your contacts." }
    return build(hit.first, hit.second)
}

private fun clock(s: String): Pair<Int, Int>? {
    val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(s.replace(".", "")) ?: return null
    var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifEmpty { "0" }.toInt()
    when (m.groupValues[3]) { "pm" -> if (h < 12) h += 12; "am" -> if (h == 12) h = 0 }
    return if (h in 0..23 && min in 0..59) h to min else null
}

private fun fmt(h: Int, m: Int) = "%d:%02d".format(h, m)

/** Opens the dialer for a contact name or number (never places the call itself). */
object ContactCallSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val target = Regex("^(?:call|phone|ring)\\s+(.+)").find(input)?.groupValues?.get(1) ?: return null
        return withTarget(ctx, target) { label, num ->
            Plan("open the dialer for $label", true) {
                ctx.launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))); "Dialer opened for $label."
            }
        }
    }
}

/** Opens the SMS composer with the text prefilled; you still press send. */
object SmsSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val rx = Regex("^(?:text|sms|message|send (?:a )?(?:text|message|sms) to)\\s+(.+?)\\s+(?:saying|that says|that|say)\\s+(.+)$",
            RegexOption.IGNORE_CASE)
        val m = rx.find(raw.trim().trimEnd('.', '!')) ?: return null
        val (target, body) = m.groupValues[1].lowercase() to m.groupValues[2]
        return withTarget(ctx, target) { label, num ->
            Plan("draft a text to $label: \"$body\"", true) {
                ctx.launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", body))
                "Message drafted. Press send to confirm."
            }
        }
    }
}

object AlarmSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val m = Regex("(?:alarm|wake me(?: up)?)\\D*?(\\d.*)$").find(input) ?: return null
        val (h, min) = clock(m.groupValues[1]) ?: return null
        return Plan("set an alarm for ${fmt(h, min)}", true) {
            ctx.launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Alarm set for ${fmt(h, min)}."
        }
    }
}

/** "remind me to X in 10 minutes" -> timer with label; "remind me to X at 5 pm" -> alarm with label. */
object ReminderSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val m = Regex("^remind me (?:to |about )?(.+)\\s+(in|at)\\s+(.+)$").find(input) ?: return null
        val what = m.groupValues[1]
        if (m.groupValues[2] == "in") {
            val t = Regex("(\\d+)\\s*(second|sec|minute|min|hour)").find(m.groupValues[3]) ?: return null
            val n = t.groupValues[1].toInt()
            val secs = when { t.groupValues[2].startsWith("h") -> n * 3600; t.groupValues[2].startsWith("m") -> n * 60; else -> n }
            return Plan("remind you to $what in $n ${t.groupValues[2]}(s)", true) {
                ctx.launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, what).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "Reminder set."
            }
        }
        val (h, min) = clock(m.groupValues[3]) ?: return null
        return Plan("remind you to $what at ${fmt(h, min)}", true) {
            ctx.launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_MESSAGE, what)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Reminder set for ${fmt(h, min)}."
        }
    }
}
