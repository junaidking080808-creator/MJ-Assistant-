package com.example.jarvis.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.jarvis.brain.*
import com.example.jarvis.skills.Plan
import com.example.jarvis.voice.Listener
import com.example.jarvis.voice.Speaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Msg(val fromUser: Boolean, val text: String)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val settings = Settings(app)
    val messages = mutableStateListOf(Msg(false, "Online. How can I help?"))
    var pending by mutableStateOf<Plan?>(null); private set
    var listening by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var partial by mutableStateOf(""); private set
    var wakeMode by mutableStateOf(false); private set
    private var awaiting = false

    private val assistant = Assistant(app, settings, LlmClient(settings))
    private val speaker = Speaker(app)
    private val listener = Listener(app,
        onPartial = { partial = it },
        onFinal = { onHeard(it) },
        onEnd = { err ->
            partial = ""
            if (wakeMode && err?.contains("(9)") != true) {
                viewModelScope.launch { delay(300); if (wakeMode) listener.start() }  // keep listening
            } else {
                if (wakeMode) wakeMode = false
                listening = false; err?.let { reply(it) }
            }
        })

    /** In wake mode only utterances starting with "Hey MJ" / "MJ" are acted on. */
    private fun onHeard(t: String) {
        if (!wakeMode) { send(t); return }
        val m = Regex("^(?:(?:hey|ok|okay|hi)\\s+)?(?:m\\.?\\s?j|em\\s?jay)\\.?(?![a-z])[,.!]?\\s*(.*)$", RegexOption.IGNORE_CASE).find(t.trim())
        val rest = m?.groupValues?.get(1)?.trim()
        if (m == null) { if (awaiting) { awaiting = false; send(t) } }
        else if (rest.isNullOrEmpty()) { awaiting = true; reply("Yes?") }
        else { awaiting = false; send(rest) }
    }

    fun toggleWake() {
        if (wakeMode) { pauseWake(); return }
        speaker.stop(); wakeMode = true; listening = true; listener.start()
    }

    /** Wake listening is foreground-only; called when the app goes to background. */
    fun pauseWake() {
        if (!wakeMode) return
        wakeMode = false; listening = false; awaiting = false; listener.cancel()
    }

    private fun reply(t: String) { messages += Msg(false, t); speaker.say(t) }

    fun send(text: String) {
        if (text.isBlank()) return
        messages += Msg(true, text); pending = null; busy = true
        viewModelScope.launch {
            when (val o = assistant.handle(text)) {
                is Outcome.Reply -> reply(o.text)
                is Outcome.Confirm -> { pending = o.plan; reply("Shall I ${o.plan.summary}?") }
            }
            busy = false
        }
    }

    fun answer(yes: Boolean) {
        val p = pending ?: return
        pending = null
        reply(if (yes) assistant.runSafely(p) else "Cancelled.")
    }

    fun toggleMic() {
        if (wakeMode) { pauseWake(); return }
        if (listening) { listener.stop(); return }
        speaker.stop(); listening = true; listener.start()
    }

    override fun onCleared() { listener.destroy(); speaker.shutdown() }
}
