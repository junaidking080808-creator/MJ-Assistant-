package com.example.jarvis.brain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class LlmClient(private val s: Settings) {
    /** history: (role, text) pairs. Calls {baseUrl}/chat/completions. */
    suspend fun chat(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content",
            "You are MJ, a concise voice assistant on an Android phone. Keep answers short and speakable."))
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", s.model).put("messages", msgs).toString()
        val c = URL(s.baseUrl.trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json")
            if (s.apiKey.isNotBlank()) c.setRequestProperty("Authorization", "Bearer ${s.apiKey}")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode >= 400) error("HTTP ${c.responseCode}")
            val text = c.inputStream.bufferedReader().readText()
            JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        } finally { c.disconnect() }
    }
}
