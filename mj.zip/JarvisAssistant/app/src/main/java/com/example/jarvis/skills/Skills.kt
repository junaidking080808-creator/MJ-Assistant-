package com.example.jarvis.skills

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.text.DateFormat
import java.util.Date

object SkillRegistry {
    val skills: List<Skill> = listOf(
        SmsSkill, ReminderSkill, AlarmSkill, TimerSkill, DialSkill, ContactCallSkill,
        TimeSkill, BatterySkill, FlashlightSkill, SearchSkill, SettingsSkill, OpenAppSkill
    )
}

private fun Context.launch(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

object TimeSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        if (!Regex("\\b(time|date|today)\\b").containsMatchIn(input)) return null
        return Plan("tell the time", false) { DateFormat.getDateTimeInstance().format(Date()) }
    }
}

object BatterySkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        if (!input.contains("battery")) return null
        return Plan("check the battery", false) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            "Battery is at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent."
        }
    }
}

object FlashlightSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        if (!Regex("flash ?light|torch").containsMatchIn(input)) return null
        val on = !Regex("\\boff\\b").containsMatchIn(input)
        return Plan("turn the flashlight ${if (on) "on" else "off"}", false) {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull() ?: return@Plan "No flashlight found."
            cm.setTorchMode(id, on)
            "Flashlight ${if (on) "on" else "off"}."
        }
    }
}

object TimerSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val m = Regex("timer.*?(\\d+)\\s*(second|sec|minute|min|hour)").find(input) ?: return null
        val n = m.groupValues[1].toInt()
        val secs = when { m.groupValues[2].startsWith("h") -> n * 3600; m.groupValues[2].startsWith("m") -> n * 60; else -> n }
        return Plan("start a timer for $n ${m.groupValues[2]}(s)", true) {
            ctx.launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Timer started."
        }
    }
}

/** Opens the dialer only (never places the call itself). */
object DialSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val m = Regex("(?:call|dial)\\s+([+\\d][\\d\\s-]{3,})").find(input) ?: return null
        val num = m.groupValues[1].filter { it.isDigit() || it == '+' }
        return Plan("open the dialer with $num", true) {
            ctx.launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))); "Dialer opened."
        }
    }
}

object SearchSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val m = Regex("^(?:search|google|look up)(?: for)?\\s+(.+)").find(input) ?: return null
        val q = m.groupValues[1]
        return Plan("search the web for \"$q\"", true) {
            ctx.launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q)); "Searching."
        }
    }
}

object SettingsSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        if (!input.startsWith("open")) return null
        val (name, action) = when {
            input.contains("wifi") || input.contains("wi-fi") -> "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS
            input.contains("bluetooth") -> "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS
            input.contains("settings") -> "Settings" to Settings.ACTION_SETTINGS
            else -> return null
        }
        return Plan("open $name settings", true) { ctx.launch(Intent(action)); "Opened $name settings." }
    }
}

object OpenAppSkill : Skill {
    override fun plan(ctx: Context, input: String, raw: String): Plan? {
        val name = Regex("^(?:open|launch|start)\\s+(.+)").find(input)?.groupValues?.get(1) ?: return null
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == name }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return null
        val label = hit.loadLabel(pm).toString()
        return Plan("open $label", true) {
            pm.getLaunchIntentForPackage(hit.activityInfo.packageName)?.let { ctx.launch(it); "Opened $label." }
                ?: "Couldn't open $label."
        }
    }
}
