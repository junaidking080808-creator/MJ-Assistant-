package com.example.jarvis.brain

import android.content.Context

/** Optional LLM endpoint (any OpenAI-compatible server: OpenAI, Ollama, LM Studio, a self-hosted gateway...). */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    var baseUrl: String
        get() = p.getString("url", "") ?: ""
        set(v) = p.edit().putString("url", v.trim()).apply()
    var apiKey: String
        get() = p.getString("key", "") ?: ""
        set(v) = p.edit().putString("key", v.trim()).apply()
    var model: String
        get() = p.getString("model", "") ?: ""
        set(v) = p.edit().putString("model", v.trim()).apply()
    val configured get() = baseUrl.isNotBlank() && model.isNotBlank()
}
