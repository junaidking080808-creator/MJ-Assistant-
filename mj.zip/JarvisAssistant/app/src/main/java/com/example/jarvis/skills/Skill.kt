package com.example.jarvis.skills

import android.content.Context

/** A planned action. If [confirm] is true the UI asks the user before [run] is called. */
class Plan(val summary: String, val confirm: Boolean, val run: () -> String)

/** Plug-in interface: add a capability by implementing this and registering it in SkillRegistry. */
interface Skill {
    fun plan(ctx: Context, input: String, raw: String): Plan?
}
