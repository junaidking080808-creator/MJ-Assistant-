package com.example.jarvis.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Cyan = Color(0xFF00E5FF)
private val Bg = Color(0xFF05080F)
private val Panel = Color(0xFF0E1726)

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()
    override fun onStop() { super.onStop(); vm.pauseWake() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                Screen(vm)
            }
        }
    }
}

@Composable
fun Screen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) vm.toggleMic() }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) { perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)) }
    LaunchedEffect(vm.messages.size) { list.animateScrollToItem((vm.messages.size - 1).coerceAtLeast(0)) }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("MJ", color = Cyan, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    vm.toggleWake() else micPerm.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (vm.wakeMode) "👂 Hey MJ: ON" else "👂 Hey MJ: OFF", color = Cyan) }
            TextButton(onClick = { showSettings = true }) { Text("⚙", color = Cyan) }
        }
        Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { Orb(vm.listening || vm.busy) }
        if (vm.partial.isNotBlank()) Text(vm.partial, color = Color.Gray, modifier = Modifier.padding(4.dp))

        LazyColumn(Modifier.weight(1f), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, modifier = Modifier.widthIn(max = 300.dp)
                        .clip(RoundedCornerShape(14.dp)).background(if (m.fromUser) Color(0xFF0B3C49) else Panel).padding(12.dp))
                }
            }
        }

        if (vm.pending != null) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.answer(true) }, modifier = Modifier.weight(1f)) { Text("Allow") }
                OutlinedButton(onClick = { vm.answer(false) }, modifier = Modifier.weight(1f)) { Text("Deny") }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Type a command…") }, singleLine = true)
            Button(onClick = { vm.send(input); input = "" }) { Text("➤") }
            Button(onClick = {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    vm.toggleMic() else micPerm.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (vm.listening) "■" else "🎤") }
        }
    }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun Orb(active: Boolean) {
    val t = rememberInfiniteTransition(label = "orb")
    val s by t.animateFloat(0.88f, 1.08f, infiniteRepeatable(tween(if (active) 500 else 1800), RepeatMode.Reverse), label = "s")
    Canvas(Modifier.size(110.dp)) {
        val r = size.minDimension / 2 * s
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = .55f), Color.Transparent), radius = r), r)
        drawCircle(Cyan, r * .55f, style = Stroke(4f))
        drawCircle(Cyan.copy(alpha = .8f), r * .2f)
    }
}

@Composable
fun SettingsDialog(vm: ChatViewModel, onClose: () -> Unit) {
    var url by remember { mutableStateOf(vm.settings.baseUrl) }
    var model by remember { mutableStateOf(vm.settings.model) }
    var key by remember { mutableStateOf(vm.settings.apiKey) }
    AlertDialog(onDismissRequest = onClose,
        title = { Text("AI server (optional)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Any OpenAI-compatible API, e.g. https://api.openai.com/v1 or http://192.168.1.5:11434/v1", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(url, { url = it }, label = { Text("Base URL") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true)
                OutlinedTextField(key, { key = it }, label = { Text("API key (if needed)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { vm.settings.baseUrl = url; vm.settings.model = model; vm.settings.apiKey = key; onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}
