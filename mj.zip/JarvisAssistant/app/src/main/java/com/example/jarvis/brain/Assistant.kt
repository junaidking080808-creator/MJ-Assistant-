package com.example.jarvis.brain

import android.content.Context
import com.example.jarvis.skills.Plan
import com.example.jarvis.skills.SkillRegistry

sealed class Outcome {
    data class Reply(val text: String) : Outcome()
    data class Confirm(val plan: Plan) : Outcome()
}

/** Routing: local skills first (offline, deterministic), then the optional LLM. */
class Assistant(private val ctx: Context, private val settings: Settings, private val llm: LlmClient) {
    private val history = mutableListOf<Pair<String, String>>()

    suspend fun handle(raw: String): Outcome {
        val input = raw.lowercase().trim().trimEnd('.', '!', '?')
        for (skill in SkillRegistry.skills) {
            val plan = skill.plan(ctx, input, raw) ?: continue
            return if (plan.confirm) Outcome.Confirm(plan) else Outcome.Reply(runSafely(plan))
        }
        if (!settings.configured)
            return Outcome.Reply("I can run phone commands offline. For open conversation, add an AI server in settings.")
        history += "user" to raw
        return try {
            val r = llm.chat(history.takeLast(12)); history += "assistant" to r; Outcome.Reply(r)
        } catch (e: Exception) { Outcome.Reply("I couldn't reach the AI server: ${e.message}") }
    }

    fun runSafely(plan: Plan): String = try { plan.run() } catch (e: Exception) { "That failed: ${e.message}" }
}
