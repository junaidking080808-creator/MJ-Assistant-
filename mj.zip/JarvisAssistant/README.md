# Jarvis Assistant (Android, Kotlin + Jetpack Compose)
Open in Android Studio (Koala+), let Gradle sync, then Build > Build APK(s).
Packages: ui | voice (STT/TTS) | brain (router + LLM client) | skills (plug-in phone commands).
Add a command: implement `Skill` and register it in SkillRegistry.
